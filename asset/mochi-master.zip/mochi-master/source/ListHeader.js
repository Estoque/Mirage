enyo.kind({
	name: "mochi.ListHeader",
	classes: "mochi-list-header"
})