enyo.kind({
	name: "mochi.CollapsableHeader",
	classes: "mochi-collapsable-header"
});

enyo.kind({
	name: "mochi.CollapsableItem",
	classes: "mochi-collapsable-item"
});

enyo.kind({
	name: "mochi.CollapsableFooter",
	classes: "mochi-collapsable-footer"
})